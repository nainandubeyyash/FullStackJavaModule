import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.lang.Exception;

import java.util.Scanner;

public class Assignment1 {
	public static void main(String[] args)throws Exception {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter text: ");
		String data=sc.nextLine();
		
        String regex="\\d+";
        Pattern p=Pattern.compile(regex);
         Matcher m=p.matcher(data);
        System.out.println("digits are: ");
		while(m.find())
		{
		     System.out.println(m.group());
		}    
	}

}
