import java.util.regex.*;
import java.util.Scanner;

public class Program1 {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter your name: ");
		String name=s.nextLine();
		System.out.println("Enter your phone no. : ");
		String phone=s.next();
		String regex="\\d{10}";
		Pattern pattern =Pattern.compile(regex);
		Matcher matcher=pattern.matcher(regex);
		if(matcher.matches())
		{
			System.out.println("valid");
		}
		else
		{
			System.out.println("invalid");
		}
		
		
	}

}
