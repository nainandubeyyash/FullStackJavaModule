import java.util.Scanner;
import java.util.regex.*;

public class Program3 {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter url: ");
		String url=s.next();
		String regex="[-a-zA-Z0-9@:%._\\+~#=]{1,256}\\.[a-zA-Z0-9()]{1,6}\\b([-a-zA-Z0-9()@:%_\\+.~#?&//=]*)";
		boolean result=url.matches(regex);
		if(result)
		{
			System.out.println("valid");
		}
		else
		{
			System.out.println("Invalid");
		}
		
		
	}

}
