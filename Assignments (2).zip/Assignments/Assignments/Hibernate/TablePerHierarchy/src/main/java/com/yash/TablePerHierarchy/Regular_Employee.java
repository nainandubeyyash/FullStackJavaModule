package com.yash.TablePerHierarchy;

public class Regular_Employee extends Employee {
	private float salary;
	private int bonus;

}
