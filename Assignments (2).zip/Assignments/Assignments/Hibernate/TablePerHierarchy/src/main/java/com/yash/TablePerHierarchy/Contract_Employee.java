package com.yash.TablePerHierarchy;

public class Contract_Employee extends Employee {
	private float pay_per_hour;
	private String contract_duration;

}
