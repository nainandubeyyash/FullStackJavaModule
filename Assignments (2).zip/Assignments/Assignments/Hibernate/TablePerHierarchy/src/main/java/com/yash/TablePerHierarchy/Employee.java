package com.yash.TablePerHierarchy;

public class Employee {
	private int id;
	private String name;

}
