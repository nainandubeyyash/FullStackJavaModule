

public class ThreadSleepDemo extends Thread {
	public void run()
	{
		for(int i=1;i<=3;i++)
		{
			try {
				Thread.sleep(1000);
				System.out.println(Thread.currentThread().getName());
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			System.out.println(i);
		}
	}	
     public static void main(String[] args) {
    	 ThreadSleepDemo t1=new ThreadSleepDemo();
    	 t1.setName("Yash Technologies");
    	 t1.start();
    	 ThreadSleepDemo t2=new ThreadSleepDemo();
    	 t2.setName("Nainan");
    	 t2.start();
     
     
	}

}
