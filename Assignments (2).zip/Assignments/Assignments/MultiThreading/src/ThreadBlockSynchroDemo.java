class BookTicket1
{
	int totalseats=12;
	void bookSeat(int seats)
	{
		synchronized(this)
		{
			if(totalseats>=seats)
			{
				System.out.println("Booked Successfully");
				totalseats=totalseats-seats;
				System.out.println("Remaining Seats: "+totalseats);
			}
			else
			{
				System.out.println("Seats are not available");
			}
		}
	}
}
public class ThreadBlockSynchroDemo extends Thread{
	static BookTicket1 b;
	int seats;
	public void run()
	{
		b.bookSeat(seats);
	}
	public static void main(String[] args) {
		b=new BookTicket1();
		ThreadBlockSynchroDemo t=new ThreadBlockSynchroDemo();
		t.seats=4;
		t.start();
	}

}
