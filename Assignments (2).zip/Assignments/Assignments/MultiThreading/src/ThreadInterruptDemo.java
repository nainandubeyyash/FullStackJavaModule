
public class ThreadInterruptDemo extends Thread{
	public void run()
	{
		try
		{
			for(int i=1;i<=3;i++)
			{
				System.out.println(i);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		ThreadInterruptDemo tid=new ThreadInterruptDemo();
		tid.start();
		tid.interrupt();
	}

}
