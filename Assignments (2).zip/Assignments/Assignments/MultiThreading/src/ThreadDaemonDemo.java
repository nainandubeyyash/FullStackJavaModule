
public class ThreadDaemonDemo extends Thread{
	public void run()
	{
		if(Thread.currentThread().isDaemon()){
			System.out.println("I am in Demon Thread");
		}
		else {
			System.out.println("I am in non-Daemon Thread");
		
		}
	}
	public static void main(String[] args) {
		System.out.println("Main Thread");
		ThreadDaemonDemo td=new ThreadDaemonDemo();
		td.setDaemon(true);;
		td.start();
	}
}

