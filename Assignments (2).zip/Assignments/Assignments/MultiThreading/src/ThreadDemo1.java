
public class ThreadDemo1 implements Runnable{
	public void run()
	{
		System.out.println("Thread Started");
	}
	public static void main(String[] args) {
    ThreadDemo1 t1=new ThreadDemo1();
    Thread t=new Thread(t1);
    t.start();
	}
}	

