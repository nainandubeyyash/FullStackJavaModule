
public class SingleTaskSingleThreadDemo extends Thread {
	public void run() {
		System.out.println("thread started");
	}
	public static void main(String[] args) {
		SingleTaskSingleThreadDemo td=new SingleTaskSingleThreadDemo();
		td.start();
		
	}

}
