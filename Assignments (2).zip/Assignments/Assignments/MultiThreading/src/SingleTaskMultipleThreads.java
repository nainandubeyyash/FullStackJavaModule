
public class SingleTaskMultipleThreads extends Thread{
	public void run() {
		System.out.println("Thread Started");
	}
	public static void main(String[]args) {
		SingleTaskMultipleThreads td1=new SingleTaskMultipleThreads();
		td1.start();
		SingleTaskMultipleThreads td2=new SingleTaskMultipleThreads();
		td2.start();
		
	}

}
