interface Cab{
	void bookCab();
	
}
public class LambdaExpressionDemo {
	public static void main(String[] args) {
	//without lambda
		/*Cab cab=new Cab() {
			public void bookCab() {
				System.out.println("booked");
				
			}
				
			};
			cab.bookCab();
	}*/
		
	//using lambda expression
	Cab cab=()->{
		System.out.println("booked");
	};
	cab.bookCab();
	}
}
	
	
