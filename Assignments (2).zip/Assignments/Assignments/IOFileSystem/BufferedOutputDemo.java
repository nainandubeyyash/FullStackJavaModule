import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
class BufferedOutputDemo
{
   public static void main(String[]args)
   {
     try
	 {
	 FileOutputStream fout=new FileOutputStream("d:/yash/xyz.txt");
	 BufferedOutputStream boutput=new BufferedOutputStream(fout);
	 int i;
	 while((i=boutput.read())!=-1)
	 {
		 fout.write(i);
	     System.out.print((char)i);
	 }
     boutput.close();
     fout.close();
     }
     catch(Exception e)
     {
        e.printStackTrace();
     }
   }
}   