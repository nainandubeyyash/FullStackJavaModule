package com.yash.mockitoJunitTestingDemo.Services;

import java.util.List;

import com.yash.mockitoJunitTestingDemo.Entities.Person;

public interface PersonService {
	
	public List<Person> getAllPerson();


}
