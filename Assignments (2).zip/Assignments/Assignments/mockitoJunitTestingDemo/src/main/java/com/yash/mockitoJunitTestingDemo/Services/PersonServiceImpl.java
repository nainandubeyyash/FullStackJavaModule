package com.yash.mockitoJunitTestingDemo.Services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.mockitoJunitTestingDemo.Entities.Person;
import com.yash.mockitoJunitTestingDemo.Repository.PersonRepository;

@Service

//Class
public class PersonServiceImpl implements PersonService {

	@Autowired
	private PersonRepository repo;

	public List<Person> getAllPerson() {
		return this.repo.findAll();
	}

	public PersonServiceImpl(PersonRepository repo) {
		this.repo = repo;
	}
}