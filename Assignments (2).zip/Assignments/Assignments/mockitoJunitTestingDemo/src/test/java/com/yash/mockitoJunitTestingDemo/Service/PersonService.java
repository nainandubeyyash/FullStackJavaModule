package com.yash.mockitoJunitTestingDemo.Service;

public interface PersonService {

}
