package com.yash.mockitoJunitTestingDemo.Repository;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.yash.mockitoJunitTestingDemo.Entities.Person;

@SpringBootTest
public class PersonRepositoryTest {
	@Autowired
    private PersonRepository personRepository;
 
    @Test
    void isPersonExitsById() {
    	Person person = new Person(1001, "Amiya", "Bhubaneswar");
        personRepository.save(person);
        Boolean actualResult = personRepository.isPersonExitsById(1001);
        assertThat(actualResult).isTrue();
    }

}
