package com.yash.mockitoJunitTestingDemo.Service;

import static org.mockito.Mockito.verify;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.yash.mockitoJunitTestingDemo.Repository.PersonRepository;
import com.yash.mockitoJunitTestingDemo.Services.PersonServiceImpl;
 
@ExtendWith(MockitoExtension.class)

public class PersonServiceImplTest {
	 @Mock private PersonRepository personRepository;
	 
	    private PersonServiceImpl personServiceImpl;
	 
	    @BeforeEach void setUp()
	    {
	        this.personServiceImpl
	            = new PersonServiceImpl(this.personRepository);
	    }
	 
	    @Test void getAllPerson()
	    {
	        personServiceImpl.getAllPerson();
	        verify(personRepository).findAll();
	    }

}
