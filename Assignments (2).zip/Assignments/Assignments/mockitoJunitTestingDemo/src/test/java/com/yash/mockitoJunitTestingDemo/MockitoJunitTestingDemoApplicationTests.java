package com.yash.mockitoJunitTestingDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockitoJunitTestingDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
