
import javax.swing.*;
public class GUIDemo {
	public static void main(String[] args) {
		JFrame f=new JFrame();
        
		JButton b=new JButton("click"); 
		b.setBounds(130,100,100, 40);
		          
		f.add(b); 
		          
		f.setSize(400,500); 
		f.setLayout(null);
		f.setVisible(true);
		
		JFrame f4= new JFrame("Label");
	     JLabel l1,l2;  
		 l1=new JLabel("first");  
		 l1.setBounds(50,50, 100,30);  
		 l2=new JLabel("Second");  
		 l2.setBounds(50,100, 100,30);  
		 f4.add(l1); f.add(l2);  
		 f4.setSize(300,300);  
		 f4.setLayout(null);  
		 f4.setVisible(true);
		 JFrame f5= new JFrame("Panel"); 
		 JPanel panel=new JPanel();  
	        panel.setBounds(40,80,200,200);    
	     
	        
	     JButton b1=new JButton("Button 1");     
	        b1.setBounds(50,100,80,30);    
	     
	           
	        panel.add(b1);  
	        f5.add(panel);  
	        f5.setSize(400,400);    
	        f5.setLayout(null);    
	        f5.setVisible(true);
	    JFrame f2= new JFrame("TextField");              
	    JTextField t1;  
	    t1=new JTextField("textfield");  
	    t1.setBounds(50,100, 200,30);  
	    f2.add(t1);  
	    f2.setSize(400,400);  
	    f2.setLayout(null);  
	    f2.setVisible(true);  
	          
	    JFrame f3= new JFrame("CheckBox");  
        JCheckBox checkBox1 = new JCheckBox("python");  
        checkBox1.setBounds(100,100, 50,50);  
        JCheckBox checkBox2 = new JCheckBox("Java", true);  
        checkBox2.setBounds(100,150, 50,50);  
        f3.add(checkBox1);  
        f3.add(checkBox2);  
        f3.setSize(400,400);  
        f3.setLayout(null);  
        f3.setVisible(true);  
        
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	      
	    new GUIDemo();
	    }

}
