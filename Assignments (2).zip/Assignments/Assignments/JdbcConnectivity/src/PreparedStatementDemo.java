import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.*;

public class PreparedStatementDemo {
	public static void main(String[] args) {
		try
		{
		
			Class.forName("com.mysql.cj.jdbc.Driver");
	
			String url="jdbc:mysql://localhost:3306/nainan";
			String user="root";
			String pass="root";
			
			Connection con=DriverManager.getConnection(url,user,pass);
			
			if(con!=null)
			{
				System.out.println("Connection is created Successfully");
			}
            else
			{
                System.out.println("Connection is not created");
            }
			String q="insert into employee values(?,?)";
			PreparedStatement ps=con.prepareStatement(q);  
			  
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));  
			  
			do{  
			System.out.println("enter id:");  
			int id=Integer.parseInt(br.readLine());  
			System.out.println("enter name:");  
			String name=br.readLine();  
			  
			  
			ps.setInt(1,id);  
			ps.setString(2,name);  
			
			int i=ps.executeUpdate();  
			System.out.println(i+" records affected");  
			  
			System.out.println("Do you want to continue: y/n");  
			String s=br.readLine();  
			if(s.startsWith("n")){  
			break;  
			}  
			}while(true);  
			  
			con.close();  
			}
		    catch(Exception e)
		    { 
		       System.out.println(e);
		    }  
	}
}
