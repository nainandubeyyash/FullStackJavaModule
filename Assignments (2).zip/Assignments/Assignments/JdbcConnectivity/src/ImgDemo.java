import java.sql.*;
import java.io.*;

public class ImgDemo {
	public static void main(String[] args) {
		try
		{
		
			Class.forName("com.mysql.cj.jdbc.Driver");
	
			String url="jdbc:mysql://localhost:3306/nainan";
			String user="root";
			String pass="root";
			
			Connection con=DriverManager.getConnection(url,user,pass);
			PreparedStatement ps=con.prepareStatement("insert into img1 values(?,?)");  
			ps.setString(1,"abc");  
			  
			FileInputStream fin=new FileInputStream("d:\\ss1.jpg");  
			ps.setBinaryStream(2,fin,fin.available());  
			int i=ps.executeUpdate();  
			System.out.println(i+" records affected");  
			          
			con.close();  
			}
		    catch (Exception e) 
		    {
		    	e.printStackTrace();
		    }  
	}

}
