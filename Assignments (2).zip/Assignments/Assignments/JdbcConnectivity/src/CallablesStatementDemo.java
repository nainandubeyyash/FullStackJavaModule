import java.sql.*;

public class CallablesStatementDemo {
	public static void main(String[] args) {
		try
		{
		
			Class.forName("com.mysql.cj.jdbc.Driver");
	
			String url="jdbc:mysql://localhost:3306/nainan";
			String user="root";
			String pass="root";
			
			Connection con=DriverManager.getConnection(url,user,pass);
			
			if(con!=null)
			{
				System.out.println("Connection is created Successfully");
			}
            else
			{
                System.out.println("Connection is not created");
            }
	}

}
