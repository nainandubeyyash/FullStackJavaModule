import java.util.Scanner;

public class Assignment5 {

	public static void main(String[] args) {
		
		    Scanner sc = new Scanner(System.in);
		try{
		    int a = sc.nextInt();
		    int b = sc.nextInt();
		
		
	        double c = a/b;
			System.out.println(c);
		   } 
		   catch (ArithmeticException e) {
			System.out.println(e.getMessage());
		}
		
		sc.close();
	}
	
}