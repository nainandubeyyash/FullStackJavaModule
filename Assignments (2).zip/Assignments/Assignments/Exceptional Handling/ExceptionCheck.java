class ExcepionCheck
{
	public static void main(String[]args)
	{
		try{
			//String s=null;
			//System.out.println(s.length());
			System.out.println("Hello");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println("bye");
	}
}	