public class EnumSeasons
{
	enum Seasons{
		SUMMER(8),WINTER(9),RAINY(8),SPRING(7),AUTUMN(6);
		int val;
		Seasons(int val)
		{
			this.val=val;
		}
	}
	
	public static void main(String[]args)
	{
		for(Seasons s:Seasons.values())
		{
            System.out.println(s + " "+s.val);
        }
    }
}	
	