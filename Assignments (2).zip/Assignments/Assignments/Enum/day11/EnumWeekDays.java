class EnumWeekDays
{
   enum Weekdays{
   MONDAY,TUESDAY,WEDNESDAY,THURDAY,FRIDAY,SATURDAY,SUNDAY;
   }
   public static void main(String[]args)
   {
      Weekdays[] daysOfWeek=Weekdays.values();
	  for(Weekdays today : daysOfWeek)
	  {
	    switch(today)
	    {
		   case MONDAY:
		   System.out.println("monday");
		   break;
		   
		   case TUESDAY:
		   System.out.println("tuesday");
		   break;
		   
		   case WEDNESDAY:
		   System.out.println("wednesday");
		   break;
		   
		   case THURDAY:
		   System.out.println("thursday");
		   break;
		   
		   case FRIDAY:
		   System.out.println("friday");
		   break;
		   
		   case SATURDAY:
		   System.out.println("saturday");
		   break;
		   
		   case SUNDAY:
		   System.out.println("sunday");
		   break;
		}
      }
	    System.out.println("Value of:"+Weekdays.valueOf("MONDAY"));	
    	System.out.println("Index of:"+Weekdays.valueOf("FRIDAY").ordinal());
    }
}	
		 