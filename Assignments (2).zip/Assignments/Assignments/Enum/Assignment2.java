import java.io.Serializable;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.File;
import java.util.Scanner;

class Employee implements Serializable {
	private String name;
    private String department;
    private String designation;
    private double salary;
	
	Employee()
	{
		System.out.println("no argument constructor");
	}
	public Employee(String name, String department, String designation, double salary){
	
	    this.name=name;
		this.department=department;
		this.designation=designation;
		this.salary=salary;
	
	}
	
	public String toString() {
		return name +" "+ department +" "+ designation+" "+ salary ;
}



	public static void main(String[]args)throws IOException, ClassNotFoundException{
		
		String empName, empDesignation, empDepartment;
		double empSalary;
		
		Scanner sc = new Scanner(System.in);
		File f=new File("d:/yash/yash.txt");
		ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(f));
		
		System.out.print("Enter name: ");
		empName=sc.nextLine();
		System.out.print("Enter department: ");
		empDepartment=sc.nextLine();
		System.out.print("Enter designation: ");
		empDesignation=sc.nextLine();
		System.out.print("Enter salary: ");
		empSalary=sc.nextDouble();
		sc.nextLine();
		
		Employee e=new Employee(empName,empDepartment,empDesignation,empSalary);
		out.writeObject(e);
		out.close();
		ObjectInputStream in =new ObjectInputStream(new FileInputStream(f));
		Employee e1=(Employee)in.readObject();
		System.out.println(e1);
		in.close();
	}


}