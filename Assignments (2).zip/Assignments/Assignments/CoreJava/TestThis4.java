class TestThis4
 {  
  void m(TestThis4 obj)
  {  
   System.out.println("method is invoked");  
  }  
  void p()
  {  
   m(this);  
  }  
  public static void main(String args[]){  
  TestThis4 s1 = new TestThis4();  
  s1.p();  
  }  
}  