import java.util.Scanner;
class StringDemo9 {

    public static void main(String[] args) {
       
        Scanner sc= new Scanner(System.in);
        String s1= sc.nextLine();
       
        String s2=null;
        int lenght=s1.length();
        int n=lenght/2;
        if(lenght%2==0)
        { 
          s2="";
            for(int i=0;i<n;i++){
                s2=s2+s1.charAt(i);
               
            }
            System.out.print(s2);
        }
        else
        System.out.println(s2);
        sc.close();
    }

}

    
   