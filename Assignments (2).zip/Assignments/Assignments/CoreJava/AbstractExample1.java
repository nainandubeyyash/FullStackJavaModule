abstract class Gadgets
{
   abstract void start();
   void show()
   {
      System.out.println("In Abstract class");
   }
}
class Laptop extends Gadgets
{
    void start()
    {
       System.out.println("Starts by Key/Button");
    }
}
class SmartPhone extends Gadgets
{
     void start()
     {
        System.out.println("Starts By power button");
     }
     public static void main(String[]args)
     {
     //Gadgets g=new Gadgets();
     Laptop l=new Laptop();
     l.show();
     l.start();
     SmartPhone sp=new SmartPhone();
     sp.start();
     }
}