class Outer
{
	void show1()
	{
		
	}

    static class Inner
    {
      
      void show()
      {
      System.out.println("OuterShow");
      }
    }
}
public class OuterDemo1
{
   public static void main(String[] args)
   {
    //Outer o=new Outer();
    Outer.Inner oi=new Outer.Inner();//static inner class
    oi.show();
   }
}   