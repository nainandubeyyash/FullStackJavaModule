class Fruit
{ 
   String name;
   String taste;
   String size;
   Fruit(String name, String taste, String size)
   {
      this.name=name;
      this.taste=taste;
      this.size=size;
   }
   void eat()
   {
      System.out.println(name+taste+size);
   }
}
class Apple extends Fruit
{
   void eat()
   {
      System.out.println("Apple"+"Sweet"+"small");
   }
}
class Orange extends Fruit
{
   void eat()
   {
      System.out.println("Orange"+"Sweet"+"small");
   }
}
class OverridingProblem1
{
   public static void main(String[]args)
   {
      Apple a=new Apple();
      a.eat();
      Orange o=new Orange();
      o.eat();
    }
}