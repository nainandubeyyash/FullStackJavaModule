class Vehicle
{  
  void run()
  {
  System.out.println("Vehicle is running");}  
}  
class Car extends Vehicle
{  
    void run()
    {
      System.out.println("Car is running safely");
    }  
  
    public static void main(String args[])
   {  
    Car obj = new Car(); 
    obj.run();
   }  
}  