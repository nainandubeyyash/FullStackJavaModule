class JaggedArrayDemo
{
  public static void main(String[]args)
   {
     //int[][] a={{10,20,30},{40,50},{60,70,80}};
       //System.out.println(a);
      // System.out.println(a[0]);
      // System.out.println(a[0][0]);
     
       //System.out.println(a[0][0].length) error: int can't be dereferred
       //System.out.println(a[1].length);
     int[][] b=new int[2][];
     b[0]=new int[3];
     b[1]=new int[2];
     //b[2]=new int[3];
     
      //System.out.println(b);
      System.out.println(b[0]);
      //System.out.println(b[0][0]);
      //System.out.println(b.length);
      //System.out.println(b[0][0].length);
    
    }
}