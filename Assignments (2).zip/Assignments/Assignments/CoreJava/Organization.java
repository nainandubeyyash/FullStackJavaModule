class Employee1//encapsulation
{
    private int emp_id;//data hiding
    public void setEmpId(int emp_id)
    {
       this.emp_id=emp_id;
    }
    public int getEmpId()
    {
       return emp_id;
     }
}
class Organization
{
   public static void main(String[]args)
   {
      Employee1 e1=new Employee1();
      e1.setEmpId(1000);
      System.out.println(e1.getEmpId());
   }
}