class SumAvg
{
public static void main(String[] args) 
    {
        int n, sum = 0;
        float average;
       
        int a[] = new int[]{9,5,8,9,6};
        
        for(int i = 0; i < 5 ; i++)
        {
         
            sum = sum + a[i];
        }
        System.out.println("Sum:"+sum);
        average = (float)sum / n;
        System.out.println("Average:"+average);
    }
}