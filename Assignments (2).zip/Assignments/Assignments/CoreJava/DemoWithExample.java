class Demo1
{
  int i; //instance variable
  void setValue(int i)//local variable
  {
     this.i=i;//15
  }
  void show()
  {
    System.out.println(i);
   }
}
class DemoWithExample{
   public static void main(String[]args)
   {
    Demo1 d=new Demo1();
    d.setValue(15);
    d.show();
    }
}