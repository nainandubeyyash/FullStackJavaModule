import java.io.*;  
class BufferedReaderDemo
{    
   public static void main(String args[])throws Exception
   {             
    InputStreamReader r=new InputStreamReader(System.in);    
    BufferedReader br=new BufferedReader(r);            
    System.out.print("Enter username:");    
    String name=br.readLine();    
      
    System.out.println("Name: "+name);    
 
		
    }
} 