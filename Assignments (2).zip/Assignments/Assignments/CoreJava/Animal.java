class Animal
{
  public void eat()
  {
    System.out.println("I am eating");
   }
  public static void main(String[]args)
  {
    System.out.println("Hello");
    Animal sheru=new Animal();
    sheru.eat();
    sheru.run();
    Animal a1=new Animal();
    a1.run();
    a1.eat();
    Birds b1=new Birds();
    b1.fly();
   }
   public void run()
   {
      System.out.println("I am running");
   }
}
class Birds
{
  void fly()
  {
    System.out.println("I am flying");
  }
}