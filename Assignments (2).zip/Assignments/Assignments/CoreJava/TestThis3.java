class Demo
{  
  Demo()
  {
    System.out.println("a");
   }  
  Demo(int i){  
  this();  
  System.out.println(x);  
 }  
}  
class TestThis3
{  
  public static void main(String args[])
  {  
  Demo a=new Demo(10);  
 }
}  