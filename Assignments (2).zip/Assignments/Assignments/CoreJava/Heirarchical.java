class Vehicle //Hierarchical
{
   void displayVehicle()
   {
      System.out.println("class Vehicle");
   }
}
class Car extends Vehicle
{
    void displayCar()
    {
       System.out.println( "Class Car");
    }
   
 }
class Bus extends Vehicle
{
    void displayBus()
    {
       System.out.println("Class Bus");
    }
    public static void main(String[]args)
    {
       Vehicle ob1=new Vehicle();
       ob1.displayVehicle();
       Car ob2=new Car();
       ob2.displayVehicle();
       ob2.displayCar();
       Bus obj3=new Bus();
       obj3.displayVehicle();
       obj3.displayBus();
      }
}