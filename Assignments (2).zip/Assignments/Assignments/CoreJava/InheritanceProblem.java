class Animal
{
   void eat()
   {
    System.out.println("eat");
   }
   void sleep()
   {
     System.out.println("run");
    }
}
class Bird extends Animal
{
   void fly()
   {
      System.out.println("fly");
   }
   public static void main(String[]args)
   {
    Animal a=new Animal();
    a.eat();
    a.sleep();
    Bird b=new Bird();
    b.eat();
    b.sleep();
    b.fly();
  }
}