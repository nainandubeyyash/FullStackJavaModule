class ConstructorDemo
{ 
  int age;
  String name;
  ConstructorDemo()
  {
  System.out.println("No arg constructor");
  }
  ConstructorDemo(String s, int i)
  {
  this.name=name;
  this.age=age;
  }
  public static void main(String[]args)
  {
  ConstructorDemo d1=new ConstructorDemo("Nainan", 21);
  }
} 