class SwapNos{  
    public static void main(String[] args) {  
       int t;  
       int x=Integer.parseInt(args[0]);
       int y=Integer.parseInt(args[1]);  
       System.out.println("before swapping numbers: "+x +"  "+ y);  
      
       t = x;  
       x = y;  
       y = t;  
       System.out.println("After swapping: "+x +"   " + y);  
       System.out.println( );  
    }    
} 