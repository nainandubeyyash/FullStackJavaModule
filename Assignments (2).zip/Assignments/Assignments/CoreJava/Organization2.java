class Employee2
{
   private int emp_id;
   public void setEmpId(int emp_id)
   {
      this.emp_id=emp_id;
    }
   public int getEmpId()
   {
      return emp_id;
   }
}
class Organization2
{
   public static void main(String[]args)
   {
      Employee2 e2=new Employee2();
      e2.setEmpId(500);
      System.out.println(e2.getEmpId());
   }
}