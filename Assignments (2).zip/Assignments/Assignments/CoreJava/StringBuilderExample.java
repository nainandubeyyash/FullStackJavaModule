class StringBuilderExample {
	public static void main(String[] args)
		
	{

		
		StringBuilder str= new StringBuilder();

		str.append(args[0]);

		
		System.out.println("String = "+ str.toString());

		
		StringBuilder str1= new StringBuilder("xyz");

		
		System.out.println("String1 = "+ str1.toString());

		StringBuilder str2= new StringBuilder(10);

		System.out.println("String2 capacity = "+ str2.capacity());

		
	}
}

