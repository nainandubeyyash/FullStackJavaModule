class Box {
    double height,width,depth;
  
     Box(double width,double height,double depth)
    {
        this.height=height;
        this.width=width;
        this.depth=depth;
    }
    double volume()
    { double volume;
    volume=height*width*depth;
    return volume;
    }
   
    public static void main(String[] args) 
    {
       Box b = new Box(15.6,7.6,8.8);
       System.out.println(b.volume());

    }

}

   