class SumAverage
{
  public static void main(String[]args)
  {
int a[]=new int[5];
int a[5]={1,2,3,4,5,6};
int sum=0;
float average;
sum=sum + a[5];
average=(float)sum/5;
System.out.println(sum);
System.out.println(average);
  }
}
