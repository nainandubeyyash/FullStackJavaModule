class StringDemo2
{
  public static void main(String[]args)
  {
   String s=new String("Hi There");
   System.out.println(s.trim()+"Nainan");
  }
}