import java.io.*;  
public class BufferedReaderDemo
{    
   public static void main(String args[])throws Exception
   {             
    InputStreamReader r=new InputStreamReader(System.in);    
    BufferedReader br=new BufferedReader(r);            
    System.out.println("Enter username:");    
    String name=br.readLine();    
    System.out.println("Enter password:");
    char ch=br.readPassword();
    
    System.out.println("Username:"+name+"Password:+"+ch);
		
        }
} 