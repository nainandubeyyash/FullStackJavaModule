class A //Hierarchical
{
   void displayA()
   {
      System.out.println("A Class");
   }
}
class B extends A
{
    void displayB()
    {
       System.out.println("B Class");
    }
   
 }
class C extends A
{
    void displayC()
    {
       System.out.println("C Class");
    }
    public static void main(String[]args)
    {
       A ob1=new A();
       ob1.displayA();
       //obj1.displayC();
       B ob2=new B();
       ob2.displayA();
       ob2.displayB();
       C obj3=new C();
       obj3.displayA();
       obj3.displayC();
      }
}