class Outer 
{
   class Inner
   {
     void show()
	 {
	  System.out.println("Outer show");
	  }
	}
}
class OuterDemo1
{
   public static void main(String[] args)
   {
     //Outer o=new Outer();
     Outer.Inner oi=new Outer.Inner();//static    
     oi.show();
	}
}	