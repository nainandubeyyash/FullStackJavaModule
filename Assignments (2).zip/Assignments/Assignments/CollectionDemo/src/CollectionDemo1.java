import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
public class CollectionDemo1 {
	public static void main(String[] args) {
		ArrayList<String> a=new ArrayList<>();
		//a.add(10);
		a.add("Yash");
		//a.add('j'); // without generics we should write like: javac A.java -Xlint:Unchecked
		HashSet h=new HashSet();
		h.add("technologies");
		h.add(30);
		HashMap hm=new HashMap();
		hm.put(1000, "jay");
		hm.put(1001, "tech");
		
		System.out.println(a);
		System.out.println(h);
		System.out.println(hm);
	}

}
