package mypackage2;
public class Start2
{
   public void display()
   {
      System.out.println("In display method in Start class");
   }
} 