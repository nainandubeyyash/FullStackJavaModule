class BookTicket2
{
	int totalseats=12;
	synchronized void bookSeat(int seats)
	{
		if(totalseats>=seats)
		{
			System.out.println("Booked Successfully");
			totalseats=totalseats-seats;
			System.out.println("Remaining Seats: "+totalseats);
		}
		else
		{
			System.out.println("Seats are not available");
		}
	}
}
public class ThreadMethodSynchroDemo extends Thread{
	static BookTicket2 b;
	int seats;
	public void run()
	{
		b.bookSeat(seats);
	}
	public static void main(String[] args) {
		b=new BookTicket2();
		ThreadMethodSynchroDemo t=new ThreadMethodSynchroDemo();
		t.seats=4;
		t.start();
	}

}
