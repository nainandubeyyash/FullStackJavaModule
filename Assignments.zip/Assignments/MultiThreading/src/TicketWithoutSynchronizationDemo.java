class BookTicket
{
	int totalseats=12;
	void bookSeat(int seats)
	{
		if(totalseats>=seats)
		{
			System.out.println("Booked Successfully");
			totalseats=totalseats-seats;
			System.out.println("Remaining Seats: "+totalseats);
		}
		else
		{
			System.out.println("Seats are not available");
		}
	}
}
public class TicketWithoutSynchronizationDemo extends Thread{
	static BookTicket b;
	int seats;
	public void run()
	{
		b.bookSeat(seats);
	}
	public static void main(String[] args) {
		b=new BookTicket();
		TicketWithoutSynchronizationDemo t=new TicketWithoutSynchronizationDemo();
		t.seats=4;
		t.start();
	}

}
