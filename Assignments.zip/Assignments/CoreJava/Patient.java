class Patient
{
  String patientName;
  double height;
  double weight;
  double heightM;
  Patient(double weight,double height,double heightM)
  {
   this.weight=weight;
   this.height=height;
   this.heightM=heightM;
  }
  double computeBMI()
  {
    double BMI;
    BMI=weight/height*heightM;
    return BMI;
    }
   
    public static void main(String[] args) 
    {
       Patient p = new Patient(60,150,15);
       System.out.println(p.computeBMI());

    }

}
