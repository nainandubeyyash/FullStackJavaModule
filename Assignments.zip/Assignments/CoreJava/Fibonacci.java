class Fibonacci
{
public static void main(String[]args)
{
int sum=0;
int a=0;
int b=1;
int n =Integer.parseInt(args[0]);
System.out.println("Fibonacci Series: ");
while(Fibonacci(sum) <= n)
{
System.out.print(Fibonacci(sum) + " ");
sum++;
}
}
