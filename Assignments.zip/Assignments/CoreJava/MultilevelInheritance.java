class Gadgets 
{
   void displayGadgets()
   {
      System.out.println(" Gadgets Class");
   }
}
class Television extends Gadgets
{
    void displayTelevision()
    {
       System.out.println("Television Class");
    }
   
 }
class Shows extends Television
{
    void displayShows()
    {
       System.out.println("Shows Class");
    }
    public static void main(String[]args)
    {
       Gadgets ob1=new Gadgets();
       ob1.displayGadgets();
       Television ob2=new Television();
       ob2.displayGadgets();
       ob2.displayTelevision();
       Shows obj3=new Shows();
       obj3.displayTelevision();
       obj3.displayShows();
      }
}