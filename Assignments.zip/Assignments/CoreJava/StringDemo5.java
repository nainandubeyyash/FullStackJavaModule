class StringDemo5
{
  public static void main(String[]args)
  {
   String s1=new String("There");
   String s2=new String("There");
   System.out.println(s1.compareTo(s2));
  }
}