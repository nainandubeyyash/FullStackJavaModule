interface Gadget
{
   void show();
}
interface Tool
{
    void display();
}
class SmartPhone implements Gadget,Tool
{
   public void show()
   {
       System.out.println("In show method");
   }
   public void display()
   {
       System.out.println("in display method");
   }
   public static void main(String[]args)
   {
      SmartPhone sp=new SmartPhone();
      sp.show();
      sp.display();
    }
}