class Person
{
  String dateOfBirth="4/9/2000";
  void displayDOB()
  {
     System.out.println(dateOfBirth);
   }
  String name="Nainan Dubey";
  void displayName()
  {
     System.out.println(name);
  } 
}
class Teacher extends Person
{
  int salary=50000;
  void displaySalary()
  {
     System.out.println(salary);
  }
  String subject="Java Programming";
  void displaySubject()
  {
     System.out.println(subject);
   }
}
class Student extends Person
{
  int studentId=101;
  void displayStudentId()
  {
     System.out.println(studentId);
  }
}
class CollegeStudent extends Student
{
  String collegeName="UIT RGPV";
  String year="second";
  void displayCollegeName()
  { 
     System.out.println(collegeName);
  }
  void displayYear()
  {
    System.out.println(year);
  }
  public static void main(String[]args)
  {
     Person p=new Person();
     p.displayDOB();
     p.displayName();
     Teacher t=new Teacher();
     t.displaySalary();
     t.displaySubject();
     t.displayDOB();
     t.displayName();
     Student s=new Student();
     s.displayStudentId();
     s.displayDOB();
     s.displayName();
     CollegeStudent cs=new CollegeStudent();
     cs.displayYear();
     cs.displayCollegeName();
     cs.displayStudentId();
    }
}