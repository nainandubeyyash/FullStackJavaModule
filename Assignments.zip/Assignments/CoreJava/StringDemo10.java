class StringDemo10 {
        public static String
 	removeFirstandLast(String s)
	{

		 s = s.substring(1, s.length() - 1);

		return s;
	}


	public static void main(String args[])
	{
		
		String s = args[0];

		
		System.out.print(removeFirstandLast(s));
	}
}
