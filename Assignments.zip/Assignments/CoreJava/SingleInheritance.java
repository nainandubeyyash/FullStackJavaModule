class Books
{
   void displayBooks()
   {
      System.out.println("Books Class");
   }
}
class Novel extends Books
{
    void displayNovel()
    {
       System.out.println("Novel Class");
    }
    public static void main(String[]args)
    {
        Books ob1=new Books();
        ob1.displayBooks();
        Novel obj2=new Novel();
        obj2.displayBooks();
        obj2.displayNovel();
     }
}