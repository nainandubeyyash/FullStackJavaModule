class StringDemo7
{
  public static void main(String[]args)
  {
   String s1=new String("Good Day");
  
   System.out.println(s1.substring(0,3));
  }
}