class StringCatDemo
{
  public static void main(String[]args)
  {
      String s=new String("yash");
      s.concat("Tech");
      System.out.println(s);
      s=s.concat("Technologies");
      System.out.println(s);
   }
}