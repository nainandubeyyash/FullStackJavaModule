class T1
  {  
   int r;  
   String s;  
   T1(int r,String s)
   {  
   r=r;  
   s=s;   
  }  
  void display()
  {
    System.out.println(r+" "+s+);
  }  
}  
class TestThis1{  
  public static void main(String args[]){  
  T1 s1=new T1(111,"Nainan");  
  T1 s2=new T1(112,"sumit");  
  s1.display();  
  s2.display();  
}
}  