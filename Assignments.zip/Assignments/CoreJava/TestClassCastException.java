class A
{
   int i=2;
}
class B extends A
{
   int j=5;
}
class TestClassCastException
{
  public static void main(String[]args)
  {
    A a=new A();
    B b=(B)a;
    System.out.println(a.i);
   }
}