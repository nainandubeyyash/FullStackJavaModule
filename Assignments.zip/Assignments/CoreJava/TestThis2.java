class Demo{  
   void m()
   {
     System.out.println("m");
   }  
  void n()
  {  
  System.out.println("n");  
  this.m();  
 }  
}  
class TestThis2
{  
  public static void main(String args[])
 {  
  Demo d=new Demo();  
  d.n();  
 }
}  