class Circle
{
  private int rad;
  public Circle(int rad)
  {
     this.rad=rad;
  }
  public double area()
  {
     return Math.PI*Math.pow(rad,2);
  }
  public int getRad()
  {
     return rad;
  }
}
class Cylinder extends Circle
{
   private int height;
   public Cylinder(int rad, int height)
   {
     super(rad);
     this.height=height;
   }
   public double area()
   {
      return 2*super.area()+2*Math.PI*getRad()*height;
   }
}
class UseCylinder
{
  public static void main(String[]args)
  {
     Cylinder obj=new Cylinder(10,20);
     System.out.println("Cylinder Area:"+obj.area());
   }
}
     