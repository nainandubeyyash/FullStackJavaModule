class Middle 
{
public static void main(String[]args)
{
  int a[]=new int[]{2,3,2};
  int b[]=new int[]{7,8,9};


 

  int lenA = a.length / 2;
  int lenB = b.length / 2;

  int arr[] = new int[2];


 for (int i = 0; i < lenA; i++) {
    arr[0] = a[lenA-1];


   }
 for (int i = 0; i < lenB; i++) {
     arr[1] = b[lenB];


  }


 return arr[];
 }
}