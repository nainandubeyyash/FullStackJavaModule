class ArrayCreateDemo
{
   public static void main(String args[])
    {
      int[]a=new int[7];
     }
}