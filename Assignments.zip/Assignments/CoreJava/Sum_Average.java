public class Sum_Average
{
    public static void main(String[] args) 
    {
        int sum = 0;
        float average;
       
        int a[] = new int[5]{10,20,30,40,50};
        
            sum = sum + a[i];
        }
        System.out.println("Sum:"+sum);
        average = (float)sum / n;
        System.out.println("Average:"+average);
    }
}