class TypesVariable
{
  int a=20;//intance variable
  static int b=30;//staic variable
  void add()
  {
    int c;//local variable
    c=a+b;
    System.out.println(c);
  }
  public static void main(String[] args)
  {
     TypesVariable ob1=new TypesVariable();//object created
     //a.add();
     System.out.println(ob1.a);//20
     System.out.println(ob1.b);//30
     ob1.a=50;
     ob1.b=450;
     System.out.println(ob1.a);//50
     System.out.println(ob1.b);//450
     TypesVariable ob2=new TypesVariable();
     System.out.println(ob2.a);//20
     System.out.println(ob2.b);//450
  }
}
