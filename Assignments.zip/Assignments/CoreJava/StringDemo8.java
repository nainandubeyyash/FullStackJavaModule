class StringDemo8
{
  public static void main(String[]args)
  {
   
   String a=new String(args[0]);
   String b=new String();
   int n = a.length();
        for(int i = n - 1; i >= 0; i--)
        {
            b = b + a.charAt(i);
        }
        if(a.equalsIgnoreCase(b))
        {
            System.out.println("The string is palindrome.");
        }
        else
        {
            System.out.println("The string is not palindrome.");
  }
}
}