class Demo6{

 Demo6 getDemo6(){
 return this;
 }
 void display()
 {
   System.out.println("hi");
 }
}

class TestThis6
{
   public static void main(String args[])
   {
    new Demo6().getDemo6().display();
	}
}
