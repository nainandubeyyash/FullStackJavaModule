class ArrayRetDemo
{
   public static void main(Stirng[]args)
    {
       int[] a={10,20,30};
       for(int i=0; i<a.length;i++)
       {
          System.out.println(a[i] +" '");
        }
     }
}