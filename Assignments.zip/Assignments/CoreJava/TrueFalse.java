

class TrueFalse

{

public static void main ( String args [] )

{


int i, k=0 ;

int a [] = new int [5] ;



for ( i=0;i<a.length;i++)

{

a [i] =Integer.parseInt(args[0]);

}



for ( i=0;i<a.length;i++)

{

if ( a [ i ] == 1 || a [ i ] == 4 )

k++;

}

if ( k == a.length )

System.out.println (" True ");

else

System.out.println (" False ");

}

}