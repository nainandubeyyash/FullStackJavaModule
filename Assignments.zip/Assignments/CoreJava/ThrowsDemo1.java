import java.io.FileInputStream;
import java.io.ClassNotFoundException;
class ThrowsD
{
    void show()throws ClassNotFoundException
    {
       FileInputStream f=new FileInputStream("d./yash.txt");
	}
}
	
class ThrowsDemo1
{
   public static void main(String[]args)
   {
      ThrowsD t=new ThrowsD();
	  try{
      t.show();	  
	  }
	  catch(ClassNotFoundException e)
	  {
          e.printStackTrace();
      }
      System.out.println("Hello-normal Termination");
    }
}	