class A
{
   void displayA()
   {
      System.out.println("A Class");
   }
}
class B extends A
{
    void displayB()
    {
       System.out.println("B Class");
    }
    public static void main(String[]args)
    {
        A ob1=new A();
        ob1.displayA();
        //ob1.displayB();
        B obj2=new B();
        obj2.displayA();
        obj2.displayB();
     }
}