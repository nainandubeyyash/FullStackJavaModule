import javax.swing.JOptionPane;

public class SimpleInputDialog 
{

    public static void main(String[] args)
    {

        String m = JOptionPane.showInputDialog("Write your name");
        System.out.println(m);

    }

}