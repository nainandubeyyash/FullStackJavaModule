class StringDemo4
{
  public static void main(String[]args)
  {
   String s1=new String("Hi There");
   String s2=new String("hi there");
   System.out.println(s1.equalsIgnoreCase(s2));
   
  }
}