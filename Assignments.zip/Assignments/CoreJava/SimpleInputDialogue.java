import javax.swing.JOptionPane;

public class SimpleInputDialog 
{

    public static void main(String[] args)
    {

        String m = JOptionPane.showInputDialog("hi");
        System.out.println(m);

    }

}