class MethodOverload
{
   void show(int a, String b)
   {
     System.out.println("First method calling");
    }
   void show(String a, int b)
   {
     System.out.println("Second method calling");
   }
   //String show(int a)//error
   void show(int a)
   {
     System.out.println("third method calling");
   }
   public static void main(String[]args)
   {
      MethodOverload ml=new MethodOverload();
      ml.show(10);
      ml.show(10,"neha");
      ml.show("neha",10);
    }
}