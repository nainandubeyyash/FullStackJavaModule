class Sums
{ 
  public static void main(String[]args)
   {
    int n[]=new int[]{23,56,78,6,89,7,8,9};
    int sum=0;
    for (int i=0; i<n.length-1; i++) {
    if (n[i]==6 && n[i+1]==7) {
         continue;
     }
     else{
         sum+=n[i];
     }
}
System.out.println(sum);
}
}