public class Exercise1 {

    
  public static void main(String[] args)
    {
        int input=Integer.parseInt(args[0]);
         System.out.print("Input number: ");

        if (input > 0)
        {
            System.out.println("Number is positive");
        }
        else if (input < 0)
        {
            System.out.println("Number is negative");
        }
        else
        {
            System.out.println("Number is zero");
        }
    }
}