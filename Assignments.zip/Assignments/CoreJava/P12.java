class P12
{
  public static void main(String[]args)
  {
   public int[] evenOdd(int[] nums) {

   boolean oddFound=false;
   int count=-1;
   int oddGap=0;

   for(int i=0;i<nums.length;i++)
   {
       if(!(oddFound)&(nums[i]%2==0))
        continue;

       if((!oddFound)&(nums[i]%2==1))
       {
         oddFound=true;
         count=i;
         continue;
       }
       if((oddFound)&(nums[i]%2==1))
       {
         oddGap++;
         continue;
       }
        if((oddFound)&(nums[i]%2==0)) 
        {
         int temp=nums[count];
         nums[count]=nums[i];  
         nums[i]=temp;

         if(i>0)
             i--;

            if(oddGap>0)
            {
              oddGap--;
              count+=1;
              oddFound=true;
              continue;
             } 
             oddFound=false;
        } 

     }
     return nums;    

}
}
}