import java.util.Scanner;

class fruit

{    

  protected char name, taste, size  ;
  scanner sc = new scanner ( system. in );
  void eat ( )

 {

       scanner sc = new scanner ( system. in );

       System.out.println( "enter the name of the fruit " ) ;

       name = nextChar ( ) ;

       System.out.println( " please provide the taste of the fruit " ) ;

       taste = nextChar ( ) ;

       System.out.println( " Name of the fruit is: " + name ) ;

       System.out.println( " Taste of the fruit is: " + taste ) ;  

    }

}

class apple extends fruit

{

  void eat ( )

  {

       System.out.println( " Name of the fruit is Apple " ) ;

       System.out.println( " Taste of the fruit is sweet " ) ;

    }  

}

class orange extends fruit

{

   public void eat ( ) 

  {

       System.out.println( " Name of the fruit is Orange " ) ;

       System.out.println( "haTaste of the fruit is sour ") ;

    }

}

class OverridingProblem

{

 public static void main ( string args )

  {

    apple A = new apple( ) ;

     A.eat ( ) ;

    orange O = new orange( ) ;

    O.eat ( ) ;

  }

}