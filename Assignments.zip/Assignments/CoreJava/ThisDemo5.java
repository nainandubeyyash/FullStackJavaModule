class ThisDemo5
{
   ThisDemo5(Demo td)
   {
     System.out.println("ThisDemo5 class Constructor");
   }
   
}
class Demo
{
  void y1()
  {
    ThisDemo5 t=new ThisDemo5(this);
   }
  public static void main(String[]args)
  {
   Demo t= new Demo();
   t.y1();
  
   }
}

   
  