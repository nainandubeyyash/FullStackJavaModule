class Shape
{
  void draw()
  {
    System.out.println("dtrawing shape");
  }
  void erase()
  {
     System.out.println("erasing shape");
  }
}
class Circle extends Shape
{
   void draw()
  {
    System.out.println("dtrawing shape");
  }
  void erase()
  {
     System.out.println("erasing shape");
  }
}
class Square extends Shape
{
    void draw()
  {
    System.out.println("dtrawing shape");
  }
  void erase()
  {
     System.out.println("erasing shape");
  }
}
class Triangle extends Shape
{
     void draw()
  {
    System.out.println("dtrawing shape");
  }
  void erase()
  {
     System.out.println("erasing shape");
  }
}
class TestOverride
{
   public static void main(String[]args)
   {
   Circle c=new Circle();
   c.draw();
   c.erase();
   Triangle t=new Triangle();
   t.draw();
   t.erase();
   Square s=new Square();
   s.draw();
   s.erase();
  }
}

   