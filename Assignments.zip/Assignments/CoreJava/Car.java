class Vehicle
{  
  String s;
  String run()
  {
  System.out.println("Vehicle is running");
  } 
  return s; 
}  
class Car extends Vehicle
{  
    int i;
    int run()
    {
      System.out.println("Car is running safely");
    }  
    return i;
  
    public static void main(String args[])
   {  
    Car obj = new Car(); 
    obj.run();
   }  
}  