class StringDemo1
{
  public static void main(String[]args)
  {
   String s=new String("Yash");
   System.out.println(s.isEmpty());
  }
} 