
public class Debugger2 {
	public static void main(String[]args) {
		System.out.println("Welcome to the Debugger");
		int i=100;
		show();
		if(i<120)
		{
			System.out.println("value of i is lesser than 120");
			
		}
		else
		{
			System.out.println("value of i is greater than 120");
		}
	}
	    static void show()
	    {
	    	for(int j=1; j<=5;j++)
	    	{
	    		System.out.println(j);
	    	}
	    	
	   }

}
