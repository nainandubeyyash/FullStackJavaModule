import java.io.FileInputStream;
import java.io.FileOutputStream;
class FileInputOutputStream
{
   public static void main(String[]args)
   {

      FileInputSream in=null;new FileInputStream("d:/yash/abc.txt");
	  FileOutputStream out=null;new FileInputOutputStream("d:/yash?xyz.txt");
	  try{
	         in=new FileInputStream("d:/yash/abc.txt");
			 out= new FileInputStream("d:/yash/abc.txt");
	         int c;
	         while((c=in.read())!=-1)
	         {
	             out.write(c);
		         System.out.println((char)c);
	         }
	     }
	  catch(IOException e)
	  {
	    System.out.println(e);
	  }
	  finally{
	    if(in!=null)
		{
	      in.close();
		}
        if(out!=null)
        {		
	  out.close();
	    }
	   }

    }
	

}	