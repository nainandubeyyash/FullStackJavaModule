import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Assignment3 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no. : ");
		String data=sc.nextLine();
		
		String regex=".?|(..+?)\\1+";
        Pattern p=Pattern.compile(regex);
        Matcher m=p.matcher(data);
        
        if(!data.matches(regex)) {
        	System.out.println("prime");
        }
        else {
        	System.out.println("non-prime");
        }
     
	
}
}
