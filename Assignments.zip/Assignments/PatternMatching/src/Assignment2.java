
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class Assignment2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter text: ");
		String data=sc.nextLine();
	

		Pattern p=Pattern.compile("\\R");
		Stream<String> lines=p.splitAsStream("Line1\nLine2\nLine3");
		
		System.out.println(lines);
		
		
	}
	}

