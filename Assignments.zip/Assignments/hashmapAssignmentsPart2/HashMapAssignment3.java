package hashmapAssignments;

import hashmapAssignments.assignment3.ContactList;

public class HashMapAssignment3 {

	public static void main(String[] args) {
		ContactList contactsList = new ContactList();
		
		contactsList.addContact("abc", 98317883);
		contactsList.addContact("Police", 100);
		contactsList.addContact("xyz", 98769932);
				
		System.out.println("Police: " + contactsList.doesContactNameExist("Police"));
		System.out.println("98769932: " + contactsList.doesContactNumberExist(98769932));
		
		System.out.println();
		contactsList.listAllContacts();
	}

}