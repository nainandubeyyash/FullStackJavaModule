import java.time.LocalDate;    
public class LocalDateExample2 {    
  public static void main(String[] args) {    
    LocalDate date = LocalDate.of(2022, 4, 11);    
    System.out.println(date.isLeapYear());      
  }    
}