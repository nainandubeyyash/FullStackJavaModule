import java.util.Scanner;
import java.util.regex.*;

public class Program2 {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter your email: ");
		String email=s.next();
		String regex="^(.+)@(\\S+)$";
		boolean result=email.matches(regex);
		if(result)
		{
			System.out.println("valid");
		}
		else
		{
			System.out.println("Invalid");
		}
		
	}

}
