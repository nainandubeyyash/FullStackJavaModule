import mypackage.Start;
class MyPackage
{
   public static void main(String[]args)
   {
     //mypackage.Start ob=mypackage.Start();
	 Start ob=new Start();
	 ob.display();
   }
}   