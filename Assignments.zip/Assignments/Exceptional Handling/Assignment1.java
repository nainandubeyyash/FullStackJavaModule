
import java.util.Scanner;


public class Assignment1 {

	
	public static void main(String[] arg)
	{
		System.out.println("Please enter a number:");
		try{
        Scanner s = new Scanner(System.in);
        String input = s.nextLine();

        int number = Integer.parseInt(input);

        System.out.println("you entered: " + number);
       
        }
			

		
			catch (NumberFormatException e) {

				
				System.out.println("NumberFormatException occurred");
			}
		s.close();
	}
}
