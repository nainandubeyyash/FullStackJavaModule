import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
public class CollectionDemo3 {
	public static void main(String[] args) {
		ArrayList<String> al=new ArrayList<String>();
		al.add("A");
		al.add("B");
	    Iterator i=al.iterator();
	    while(i.hasNext())
	    {
	    	System.out.println(i.next());
	    }
	    for(String j:al)
	    {
	    	System.out.println("For each"+ j);
	    }
	    System.out.println("Get elements index 1" +al.get(1));
	    al.set(2, "yash");
	    for(String j:al)
	    {
	    	System.out.println("For each"+ j);
	    }
	    Collections.sort(al);
	    for(String j:al)
	    {
	    	System.out.println("For each"+ j);
	    }
		}

}
