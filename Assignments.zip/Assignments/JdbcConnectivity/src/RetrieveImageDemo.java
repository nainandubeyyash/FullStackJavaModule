import java.sql.*;
import java.io.*;

public class RetrieveImageDemo {
	public static void main(String[] args) {
		private void okActionPerformed(java.awt.event.ActionEvent evt)        
		{                                   
		    try {
		        String Update = name.getText();

		        Class.forName("Driver");
		        Connection connection = DriverManager.getConnection("jdbc:odbc:NewPData");
		        PreparedStatement psmnt = connection.prepareStatement("SELECT Image FROM Table1 where Name='" + Update + "'");
		        ResultSet rs = psmnt.executeQuery();
		        Blob blob = rs.getBlob("Image");
		        int b;
		        InputStream bis = rs.getBinaryStream("Image");

		        FileOutputStream f = new FileOutputStream("Image.jpg");
		        while ((b = bis.read()) >= 0) {
		            f.write(b);
		        }
		        f.close();
		        bis.close();

		        icon = new ImageIcon(blob.getBytes(1L, (int) blob.length()));

		        lblImage.setIcon(icon);

		    } catch (ClassNotFoundException e) {
		        e.printStackTrace();
	}

}
